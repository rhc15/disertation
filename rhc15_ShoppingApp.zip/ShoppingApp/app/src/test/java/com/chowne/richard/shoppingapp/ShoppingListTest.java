package com.chowne.richard.shoppingapp;

import com.chowne.richard.shoppingapp.model.Product;
import com.chowne.richard.shoppingapp.model.ShoppingList;

import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;

/**
 * Created by richard on 01/05/2017.
 */

/**
 * Test for the products to see if it holds products and can be deleted.
 */
public class ShoppingListTest {
    @Test
    public void  CreateTest(){
        ShoppingList shoppingList = new  ShoppingList("testList");
         ArrayList<Product> products = shoppingList.getProducts();
        Product product = new Product("testProduct",2);
        products.add(product);

        assertEquals( "testProduct", products.get(0).getName());
    }

    @Test
    public  void EditTest(){
        ShoppingList shoppingList = new  ShoppingList("testList");
        ArrayList<Product> products = shoppingList.getProducts();
        Product product = new Product("testProduct",2);
        products.add(product);
        product = products.get(0);
        product.setName("apples");

        assertEquals( "apples", products.get(0).getName());
    }
    @Test
    public  void DeleteTest(){
        ShoppingList shoppingList = new  ShoppingList("testList");
        ArrayList<Product> products = shoppingList.getProducts();
        Product product = new Product("testProduct",2);
        products.add(product);
        product = products.get(0);
        products.remove(product);

        assertEquals( 0, products.size());
    }


}
