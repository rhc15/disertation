package com.chowne.richard.shoppingapp;

/**
 * Created by Richard Chowne on 28/04/2017.
 */

import com.chowne.richard.shoppingapp.model.ShoppingList;

import org.junit.Test;

import java.util.ArrayList;

import static android.R.attr.name;
import static org.junit.Assert.*;

/**
 * Test ShoppingList - for products to be displayed correctly.
 */
public class LoadShoppingListTest {
    @Test
    public void LoadListTest() {
        LoadShoppingListActivity.shoppingLists = new ArrayList<>();
        LoadShoppingListActivity.shoppingLists.add( new ShoppingList( "testShoppingList" ) );

        assertEquals( "testShoppingList", LoadShoppingListActivity.shoppingLists.get( 0 ).getName());
    }


}
