package com.chowne.richard.shoppingapp.scanner;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import com.chowne.richard.shoppingapp.LoadShoppingListActivity;
import com.chowne.richard.shoppingapp.R;
import com.chowne.richard.shoppingapp.ShoppingListActivity;
import com.chowne.richard.shoppingapp.model.Product;
import com.chowne.richard.shoppingapp.model.ShoppingList;

/**
 * Created by Richard Chowne on 22/04/2017.
 */

/**
 * Android activity containing products added from the scanner.
 */
public class ManualAddProductFromScanner extends AppCompatActivity {

    /**
     * intent to create a new shopping list.
     */
    private String intentShoppingList;

    /**
     * products manually scanned in will go through a check and return the product if it is in the database if it is not it will require
     * product name and quantity then it will be added to the database and the shopping list to be viewed and also manipulated.
     *
     * @param savedInstanceState see superclass.
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manual_add_from_product_from_scanner);

        EditText nameField = (EditText) findViewById(R.id.editText4);
        nameField.setText(getIntent().getStringExtra("productName"));

        intentShoppingList = getIntent().getStringExtra("shoppingList");
    }

    /**
     * when the product that is scanned and after inputting the name and quantity and hitting submit it will add it to
     * the shopping list to be manipulated.
     *
     * @param view the current activity.
     */
    public void submit(View view) {
        EditText nameField = (EditText) findViewById(R.id.editText4);
        String name = nameField.getText().toString();

        // get quantity
        EditText quantityField = (EditText) findViewById(R.id.editText5);
        int quantity = Integer.valueOf(quantityField.getText().toString());


        for (ShoppingList shoppingList : LoadShoppingListActivity.shoppingLists) {
            if (shoppingList.getName().equals(intentShoppingList)) {
                shoppingList.getProducts().add(new Product(name, quantity));
                break;
            }
        }

        Intent intent = new Intent(this, ShoppingListActivity.class);
        intent.putExtra("shoppingList", intentShoppingList);
        startActivity(intent);
    }
}
