package com.chowne.richard.shoppingapp.scanner;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.chowne.richard.shoppingapp.HowToActivity;
import com.chowne.richard.shoppingapp.R;

import java.util.Scanner;

/**
 * Created by Richard Chowne on 21/04/2017.
 */

/**
 * Android Activity  that takes the user back if api is down or no connection is found.
 */
public class ScanBack extends AppCompatActivity {


    private String shoppingListName;

    /**
     * takes the user back to the scan back when the api si down or no internet is being detected.
     *
     * @param savedInstanceState takes the user to the scan back page when there is an error being detected.
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scan_back);
        shoppingListName = getIntent().getStringExtra("shoppingList");
    }

    /**
     * when the user clicks ok it takes them back to the scanner to scan again a new product.
     *
     * @param view the current activity.
     */
    public void ok(View view) {
        Intent intent = new Intent(this, Scanner.class);
        startActivity(intent);
    }
}
