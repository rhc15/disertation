package com.chowne.richard.shoppingapp.model;

import java.util.ArrayList;

/**
 * Created by Richard Chowne on 18/04/2017.
 */

/**
 * Android Activity that contains the shopping list which holds an arraylist of products
 */
public class ShoppingList {
    /**
     *  contains the name of the shopping list
     */
    String name;
    /**
     * arraylsit that holds the products to be viewed in the shoppinglist.
     */
    ArrayList<Product> products;

    /**
     * contructor that calls name and products to the shopping list.
     *
     * @param name name of the shopping list.
     */
    public ShoppingList(String name) {
        this(name, new ArrayList());
    }

    /**
     * creates a  shoppingList with the name and products inside it.
     *
     * @param name     name.
     * @param products  products.
     */
    public ShoppingList(String name, ArrayList products) {

        this.name = name;
        this.products = products;
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public ArrayList<Product> getProducts() {
        return products;
    }


    public void setProducts(ArrayList<Product> products) {
        this.products = products;
    }
}
