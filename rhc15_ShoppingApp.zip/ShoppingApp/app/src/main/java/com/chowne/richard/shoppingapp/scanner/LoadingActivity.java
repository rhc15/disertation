package com.chowne.richard.shoppingapp.scanner;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.chowne.richard.shoppingapp.R;

/**
 * Created by Richard Chowne on 21/04/2017.
 */

/**
 * Android Activity that contains the LoadActivty
 */
public class LoadingActivity extends AppCompatActivity {

    /**
     * the method that shows the load activity so it shows the created shoppinglists to be viewed or manipulated.
     *
     * @param savedInstanceState see superclass.
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loading_activity);

    }
}
