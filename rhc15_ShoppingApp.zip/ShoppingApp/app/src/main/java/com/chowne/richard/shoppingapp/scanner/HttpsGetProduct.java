package com.chowne.richard.shoppingapp.scanner;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Richard Chowne on 21/04/2017.
 */

/**
 * Android Activity  that gets the product via get request from teh api database.
 */
public class HttpsGetProduct extends AsyncTask<String, Void, String> {


    private Context context;
    private String gtin;
    private String shoppingListName;

    /**
     * Method that sends a get request to teh api to get a product to add it to the shopping list.
     *
     * @param context          context to the store the requested get request and print
     * @param shoppingListName returns the shoppinglist name with teh products.
     */
    public HttpsGetProduct(final Context context, final String shoppingListName) {
        this.context = context;
        this.shoppingListName = shoppingListName;
    }

    /**
     * gets the GTIN via barcode scan and returns the product scanned , and runs a through a case
     * weather it is in the databse and if it is not it will prompt you to add one.
     *
     * @param params is the gtin
     * @return will return null
     */
    @Override
    protected String doInBackground(String... params) {
        HttpURLConnection connection = null;
        gtin = params[0];
        try {
            String prefixURL = "https://api.outpan.com/v2/products/";
            String GTINURL = prefixURL + gtin;
            String completeURL = GTINURL + "?apikey=6efd51615ce50b2805738991e82ac17b";
            //creates Connection
            URL url = new URL(completeURL);
            connection = (HttpURLConnection) url.openConnection();
            int status = connection.getResponseCode();

            switch (status) {
                case 200:
                case 201:
                    //Get Response
                    InputStream is = connection.getInputStream();
                    BufferedReader rd = new BufferedReader(new InputStreamReader(is));
                    StringBuilder response = new StringBuilder(); // or StringBuffer if Java version 5+
                    String line;
                    String productName = "";
                    while ((line = rd.readLine()) != null) {
                        String trimmedLine = line.trim();
                        if (trimmedLine.startsWith("\"name\"")) {
                            productName = line.substring(12, line.length() - 1);
                            break;
                        }
                    }
                    rd.close();
                    return productName;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return null;
    }

    /**
     * Method for when scanned product is not on the database after a request is being sent.
     *
     * @param s will run if the product is not on the database an error message will be  triggered.
     */
    @Override
    protected void onPostExecute(String s) {

        if (s.equals("null")) {
            Intent intent = new Intent(context, ErrorMessage.class);
            intent.putExtra("gtin", gtin);
            intent.putExtra("shoppingList", shoppingListName);
            context.startActivity(intent);
        } else {
            Intent intent = new Intent(context, ManualAddProductFromScanner.class);
            intent.putExtra("productName", s);
            intent.putExtra("shoppingList", shoppingListName);
            context.startActivity(intent);

        }

    }
}
