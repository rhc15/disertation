package com.chowne.richard.shoppingapp.model;

/**
 * Created by Richard Chowne on 18/04/2017.
 */

/**
 * Android Activity contains the Products to go to the shoppingLists
 */
public class Product {
    /**
     * holds the name of the product.
     */
    String name;
    /**
     * holds the quantity of the product
     */
    int quantity;

    /**
     * holds the name and quantity
     *
     * @param name     the name of the product to be added to the shopping list.
     * @param quantity   quantity of the product you will want to be displayed.
     */
    public Product(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public int getQuantity() {
        return quantity;
    }


    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }


}
