package com.chowne.richard.shoppingapp.scanner;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;

import com.chowne.richard.shoppingapp.ManualAddProductActivity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Richard Chowne on 21/04/2017.
 */

/**
 * Android Activity that contains the httpAddproduct to add products to the api.
 */
public class HttpsAddProduct extends AsyncTask<String, Void, String> {

    private Context context;
    private int status;
    private String productName;
    private String shoppingListName;

    /**
     * lets you add products to the database
     *
     * @param context          context
     * @param shoppingListName shoppingListName.
     */
    public HttpsAddProduct(final Context context, final String shoppingListName) {
        this.context = context;
        this.shoppingListName = shoppingListName;
    }

    /**
     *  add a product to the database by sending a get request checking if it is there and if it is not
     * it will take you to add the product name and the quantity and then post it to the shoppinglist while also adding
     * it to the database, so you wont have to rescan it again.
     *
     * @param params  product name and the gtin
     * @return  null
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override

    protected String doInBackground(String... params) {
        HttpURLConnection connection = null;
        productName = params[0];
        String gtin = params[1];
        //adds product to the api via get request so when u scan it again it jsut adds it to the shoppinglist.

        try {
            String prefixURL = "https://api.outpan.com/v2/products/";
            String GTINURL = prefixURL + gtin;
            String completeURL = GTINURL + "/name?apikey=6efd51615ce50b2805738991e82ac17b";
            //creates Connection
            URL url = new URL(completeURL);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");

            Uri.Builder builder = new Uri.Builder().appendQueryParameter("name", productName);
            String body = builder.build().getEncodedQuery();

            OutputStreamWriter os = new OutputStreamWriter(connection.getOutputStream());
            BufferedWriter writer = new BufferedWriter(os);
            writer.write(body);
            writer.flush();
            writer.close();
            os.close();

            connection.connect();

            status = connection.getResponseCode();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return null;
    }

    /**
     * Method will run after adding the product to the database once added it will check the product name
     * and quantity it will add it to the database as well as show it on the shoppinglist.
     *
     * @param s s.
     */
    @Override
    protected void onPostExecute(String s) {
        // if product is no in database add name of the product to the database. else scan back to re register.
        if (status == 200 || status == 201) {
            Intent intent = new Intent(context, ManualAddProductIfScanner.class);
            intent.putExtra("productName", productName);
            intent.putExtra("shoppingList", shoppingListName);
            context.startActivity(intent);
        } else {
            Intent intent = new Intent(context, ScanBack.class);
            intent.putExtra("shoppingList", shoppingListName);
            context.startActivity(intent);
        }
    }
}
