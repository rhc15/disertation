package com.chowne.richard.shoppingapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.chowne.richard.shoppingapp.model.Product;
import com.chowne.richard.shoppingapp.model.ShoppingList;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * Created by Richard Chowne on 14/03/2017.
 */

/**
 * Android activity  used for storing the displaying the shopping list.
 */
public class ShoppingListActivity extends AppCompatActivity {


    private String intentShoppingList;


    public ArrayList<Button> buttons = new ArrayList();

    /**
     * initializes the shopping list from the load shopping list and runs through a check to find the one the user has
     * chosen and brings that up so that you can add products.When adding products to the shopping list, it will print out the
     * shopping list and the product name with the quantity and save it to be viewed when you go to the load list button.
     *
     * @param savedInstanceState see superclass.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shopping_list_activity);

        Intent intent = getIntent();
        intentShoppingList = intent.getStringExtra("shoppingList");
        ShoppingList currentShoppingList = null;

        for (ShoppingList shoppingList : LoadShoppingListActivity.shoppingLists) {
            if (intentShoppingList.equals(shoppingList.getName())) {
                currentShoppingList = shoppingList;
                break;
            }
        }

        final ArrayList<Product> shoppingListProducts = currentShoppingList.getProducts();
        final String shoppingListName = currentShoppingList.getName();

        String listName = "MyList";

        FileInputStream inputStream;
        try {
            inputStream = openFileInput(listName);
            InputStreamReader isr = new InputStreamReader(inputStream);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                if (line.equals(currentShoppingList.getName())) {
                    sb.append(line);
                    sb.append(System.getProperty("line.separator"));
                    sb.append(currentShoppingList.getProducts().size());
                    sb.append(System.getProperty("line.separator"));
                    for (Product product : shoppingListProducts) {
                        sb.append(product.getName());
                        sb.append(System.getProperty("line.separator"));
                        sb.append(product.getQuantity());
                        sb.append(System.getProperty("line.separator"));
                    }
                    br.readLine(); // clear off products size integer
                    for (int i = 0; i < currentShoppingList.getProducts().size(); i++) {
                        br.readLine(); // don't need to check product
                        br.readLine(); // don't need to check product quantity
                    }
                } else {
                    sb.append(line);
                    sb.append(System.getProperty("line.separator"));
                }
            }
            inputStream.close();

            FileOutputStream outputStream;
            try {
                outputStream = openFileOutput(listName, Context.MODE_PRIVATE);
                outputStream.write(sb.toString().getBytes());
                outputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (shoppingListProducts != null && !shoppingListProducts.isEmpty()) {
            TableLayout products = (TableLayout) findViewById(R.id.products);
            products.setStretchAllColumns(true);
            products.bringToFront();
            for (final Product product : shoppingListProducts) {
                TableRow tr = new TableRow(this);
                TextView c1 = new TextView(this);
                String formattedProductName = product.getName();
                if ( product.getName().length() > 15)
                {
                    formattedProductName = product.getName().substring( 0 , 15 ) + "...";
                }
                c1.setText(formattedProductName);
                TextView c2 = new TextView(this);
                c2.setText(String.valueOf(product.getQuantity()));
                Button button = new Button(this);
                button.setText("Edit");
                button.setTag(product.getName());
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        // EDIT products in the shopping list
                        for (Button button1 : buttons) {
                            if (button1.getTag().equals(v.getTag())) {
                                for (Product product : shoppingListProducts) {
                                    if (product.getName().equals((v.getTag()))) {
                                        Intent intent = new Intent(ShoppingListActivity.this, EditProductActivity.class);
                                        intent.putExtra("productName", product.getName());
                                        intent.putExtra("productQuantity", product.getQuantity());
                                        intent.putExtra("shoppingList", shoppingListName);
                                        startActivityForResult(intent, 1);
                                        break;
                                    }
                                }
                            }
                        }

                    }
                });
                buttons.add(button);
                Button button2 = new Button(this);
                button2.setText("Delete");
                button2.setTag(product.getName());
                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        // DELETES Products in the ShoppingList
                        for (Button button : buttons) {
                            if (button.getTag().equals(v.getTag())) {
                                for (Product product : shoppingListProducts) {
                                    if (product.getName().equals(v.getTag())) {
                                        shoppingListProducts.remove(product);
                                        //
                                        // edit file
                                        String listName = "MyList";

                                        FileInputStream inputStream;
                                        try {
                                            inputStream = openFileInput(listName);
                                            InputStreamReader isr = new InputStreamReader(inputStream);
                                            BufferedReader br = new BufferedReader(isr);
                                            StringBuilder sb = new StringBuilder();
                                            String line;
                                            while ((line = br.readLine()) != null) {
                                                if (line.equals(shoppingListName)) {
                                                    sb.append(line);
                                                    sb.append(System.getProperty("line.separator"));
                                                    int productCount = Integer.valueOf(br.readLine());
                                                    sb.append(productCount - 1);
                                                    sb.append(System.getProperty("line.separator"));

                                                    String productLine;
                                                    for (int i = 0; i < productCount; i++) {
                                                        productLine = br.readLine();
                                                        if (productLine.equals(product.getName())) {
                                                            br.readLine();
                                                            continue;
                                                        } else {
                                                            sb.append(productLine);
                                                            sb.append(System.getProperty("line.separator"));
                                                            sb.append(br.readLine());
                                                            sb.append(System.getProperty("line.separator"));
                                                        }
                                                    }
                                                } else {
                                                    sb.append(line);
                                                    sb.append(System.getProperty("line.separator"));
                                                }
                                            }
                                            inputStream.close();

                                            FileOutputStream outputStream;
                                            try {
                                                outputStream = openFileOutput(listName, Context.MODE_PRIVATE);
                                                outputStream.write(sb.toString().getBytes());
                                                outputStream.close();
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }

                                        break;
                                    }
                                }
                            }
                        }
                        finish();
                        startActivity(getIntent());
                    }
                });
                buttons.add(button2);
                tr.addView(c1);
                tr.addView(c2);
                tr.addView(button);
                tr.addView(button2);
                products.addView(tr);
            }
        }
    }

    //buttons

    // add products button

    /**
     * button listener: when the user clicks the add button the add productivity class will load up and you will choose from 2 buttons,
     * to be added to the shopping list.
     *
     * @param view the current activity.
     */
    public void addProduct(View view) {
        Intent intent = new Intent(this, AddProductActivity.class);
        intent.putExtra("shoppingList", intentShoppingList);
        startActivity(intent);
    }

}