package com.chowne.richard.shoppingapp.scanner;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.widget.Toast;

import com.google.zxing.Result;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

/**
 * Created by Richard Chowne on 19/04/2017.
 */
// information on how to do this was from an online source
// :https://www.sitepoint.com/requesting-runtime-permissions-in-android-m-and-n/
//github user dm77 for his help.

/**
 *  Android activity that holds the scanner activity.
  */
public class ScannerActivity extends Activity implements ZXingScannerView.ResultHandler {

    private String shoppingListName;
    private ZXingScannerView mScannerView;
    private final Integer CAMERA = 0x5;

    /**
     * lets the user see the camera is being connected to the shopping list when they
     * scan and prompts the user that permissions are required.
     *
     * @param savedInstanceState see superclass.
     */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        shoppingListName = getIntent().getStringExtra("shoppingList");
        askForPermission(Manifest.permission.CAMERA, CAMERA);
        mScannerView = new ZXingScannerView(this);
        setContentView(mScannerView);
    }

    /**
     * This method will prompt the user to enable permissions for use of
     * certain features such as the camera to be enabled. if permission is denied then a request code will be prompted
     * asking the user to activate it again.
     *
     * @param permission  prompts the user for permission to access certain features to be enabled to use this function.
     * @param requestCode  request code so that it saves the session for future use.
     */
    private void askForPermission(String permission, Integer requestCode) {
        if (ContextCompat.checkSelfPermission(ScannerActivity.this, permission) != PackageManager.PERMISSION_GRANTED) {

            // prompts user for permission when activating the scanner
            if (ActivityCompat.shouldShowRequestPermissionRationale(ScannerActivity.this, permission)) {

                //This is called if user has denied the permission before
                //In this case I am just asking the permission again
                ActivityCompat.requestPermissions(ScannerActivity.this, new String[]{permission}, requestCode);

            } else {

                ActivityCompat.requestPermissions(ScannerActivity.this, new String[]{permission}, requestCode);
            }
        } else {
            Toast.makeText(this, "" + permission + " is already granted.", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    /**
     * To resume camera activity.
     */
    public void onResume() {
        super.onResume();
        mScannerView.setResultHandler(this);
        mScannerView.startCamera();
    }

    @Override
    /**
     * Pausing the camera activity after it has scanned its first item.
     */
    public void onPause() {
        super.onPause();
        mScannerView.stopCamera();
    }

    @Override
    /**
     * Handling the result of the scanned item to be displayed in the shopping list and handled by the loading activity class.
     */
    public void handleResult(Result result) {
        new HttpsGetProduct(this, shoppingListName).execute(result.getText());

        Intent intent = new Intent(this, LoadingActivity.class);
        startActivity(intent);
    }

}




