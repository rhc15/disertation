package com.chowne.richard.shoppingapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.chowne.richard.shoppingapp.model.ShoppingList;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * Created by Richard  Chowne on 17/04/2017.
 */

/**
 * Android activity that holds the load activity so that you can see the list of shopping lists
 */
public class LoadShoppingListActivity extends AppCompatActivity {



    public static ArrayList<ShoppingList> shoppingLists;
    public ArrayList<Button> buttons = new ArrayList();

    /**
     * when load is clicked takes the user to see the saved list to be loaded upon creation.
     * As well as when the user hits the dit button and delete button to delete or edit the
     * product of their choosing.
     *
     * @param savedInstanceState see superclass.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.load_shopping_list);


        //adds list to the load shopping list and makes you edit and view it and delete it .
        if (!shoppingLists.isEmpty()) {
            TableLayout shoppingListTable = (TableLayout) findViewById(R.id.list);
            shoppingListTable.setStretchAllColumns(true);
            shoppingListTable.bringToFront();
            for (final ShoppingList shoppingList : shoppingLists) {
                TableRow tr = new TableRow(this);
                TextView c1 = new TextView(this);
                String formattedShoppingListName = shoppingList.getName();
                if ( shoppingList.getName().length() > 20)
                {
                    formattedShoppingListName = shoppingList.getName().substring( 0 , 20 ) + "...";
                }
                c1.setText(formattedShoppingListName);
                Button button = new Button(this);
                button.setText("Edit");
                button.setTag(shoppingList.getName());
                button.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        //  EDIT List in Load
                        for (Button button1 : buttons) {
                            if (button1.getTag().equals(v.getTag())) {
                                for (ShoppingList shoppingList : shoppingLists) {
                                    if (shoppingList.getName().equals((v.getTag()))) {
                                        Intent intent = new Intent(LoadShoppingListActivity.this, EditShoppingListActivity.class);
                                        intent.putExtra("shoppingList", shoppingList.getName());
                                        startActivity(intent);
                                        break;

                                    }
                                }
                            }
                        }
                    }
                });
                buttons.add(button);
                Button button2 = new Button(this);
                button2.setText("Delete");
                button2.setTag(shoppingList.getName());
                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // DELETE a shopping List in load Menu
                        for (Button button : buttons) {
                            if (button.getTag().equals(v.getTag())) {
                                for (ShoppingList shoppingList : shoppingLists) {
                                    if (shoppingList.getName().equals(v.getTag())) {
                                        shoppingLists.remove(shoppingList);
                                        // edit file
                                        String listName = "MyList";

                                        FileInputStream inputStream;
                                        try {
                                            inputStream = openFileInput(listName);
                                            InputStreamReader isr = new InputStreamReader(inputStream);
                                            BufferedReader br = new BufferedReader(isr);
                                            StringBuilder sb = new StringBuilder();
                                            String line;
                                            while ((line = br.readLine()) != null) {
                                                if (line.equals(shoppingList.getName())) {
                                                    int productsNo = Integer.valueOf(br.readLine());
                                                    for (int i = 0; i < productsNo; i++) {
                                                        br.readLine();
                                                        br.readLine();
                                                    }
                                                    continue;
                                                }
                                                sb.append(line);
                                                sb.append(System.getProperty("line.separator"));

                                            }
                                            inputStream.close();

                                            FileOutputStream outputStream;
                                            try {
                                                outputStream = openFileOutput(listName, Context.MODE_PRIVATE);
                                                outputStream.write(sb.toString().getBytes());
                                                outputStream.close();
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                        finish();
                        startActivity(getIntent());
                    }

                });

                buttons.add(button2);
                buttons.add(button);
                Button button3 = new Button(this);
                button3.setText("View");
                button3.setTag(shoppingList.getName());
                button3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // View a shoppingList in load Menu
                        Intent intent = new Intent(LoadShoppingListActivity.this, ShoppingListActivity.class);
                        for (Button button : buttons) {
                            if (button.getTag().equals(v.getTag())) {
                                for (ShoppingList shoppingList : shoppingLists) {
                                    if (shoppingList.getName().equals(v.getTag())) {
                                        intent.putExtra("shoppingList", shoppingList.getName());
                                    }
                                }
                            }
                        }
                        startActivity(intent);
                    }
                });
                tr.addView(c1);
                tr.addView(button);
                tr.addView(button2);
                tr.addView(button3);
                shoppingListTable.addView(tr);
            }
        }
    }


}
