package com.chowne.richard.shoppingapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
/**
 * Created by Richard Chowne on 18/04/2017.
 */

/**
 * Android Activity that contains the HowTOACtivity.
 */
public class HowToActivity extends AppCompatActivity {

    /**
     * initialises the how to activity through an intent.
     *
     * @param savedInstanceState see superclass.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.how_to);

        Intent intent = getIntent();


    }
}