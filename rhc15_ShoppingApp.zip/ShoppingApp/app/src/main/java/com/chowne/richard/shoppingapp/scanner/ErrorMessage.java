package com.chowne.richard.shoppingapp.scanner;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.chowne.richard.shoppingapp.R;

/**
 * Created by Richard Chowne on 21/04/2017.
 */

/**
 * Android Activity contains the error message
 */
public class ErrorMessage extends AppCompatActivity {

    /**
     * holds the gtin
     */
    private String gtin;
    /**
     * holds the shoppinglistname
     */
    private String shoppingListName;

    // takes you to the error page where user has to click between "yes" or "no" buttons

    /**
     * The error page for when the product scanned  is not in the database and the user can click "yes" to add it or "no" to scan again.
     *
     * @param savedInstanceState see superclass
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.error_message);
        gtin = getIntent().getStringExtra("gtin");
        shoppingListName = getIntent().getStringExtra("shoppingList");
    }

    /**
     * when the user clicks no it will take them back to the scan page to re-Scan a product.
     *
     * @param view the current activity.
     */
    public void no(View view) {
        Intent intent = new Intent(this, ScannerActivity.class);
        intent.putExtra("shoppingList", shoppingListName);
        startActivity(intent);
    }

    /**
     * when the user clicks "Yes" it will add it to the database and put it into the shoppingList for viewing and editing.
     *
     * @param view the current activity.
     */
    public void yes(View view) {
        Intent intent = new Intent(this, ScannerAddActivity.class);
        intent.putExtra("gtin", gtin);
        intent.putExtra("shoppingList", shoppingListName);
        startActivity(intent);
    }
}

