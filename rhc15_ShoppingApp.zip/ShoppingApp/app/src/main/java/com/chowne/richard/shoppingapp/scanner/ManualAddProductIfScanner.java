package com.chowne.richard.shoppingapp.scanner;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import com.chowne.richard.shoppingapp.LoadShoppingListActivity;
import com.chowne.richard.shoppingapp.R;
import com.chowne.richard.shoppingapp.ShoppingListActivity;
import com.chowne.richard.shoppingapp.model.Product;
import com.chowne.richard.shoppingapp.model.ShoppingList;

/**
 * Created by Richard Chowne on 22/04/2017.
 */

/**
 * Android activity that -contains the manual add product class where product name and quantity are
 * inputted and displayed on the shopping list.
 */
public class ManualAddProductIfScanner extends AppCompatActivity {

    /**
     * string that contains the name of the profucts to be displayed in the shopping list, from the manual add products
     */
    private String shoppingListName;

    /**
     * lets the suers add products manually and saves the products from the shopping list.
     *
     * @param savedInstanceState see superclass.
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manual_add_from_product_from_scanner);

        EditText nameField = (EditText) findViewById(R.id.editText4);
        nameField.setText(getIntent().getStringExtra("productName"));
        shoppingListName = getIntent().getStringExtra("shoppingList");
    }

    /**
     * when user hits the view they will be ableto view the shopping list and what products it holds.
     *
     * @param view the current activity.
     */
    public void submit(View view) {
        EditText nameField = (EditText) findViewById(R.id.editText4);
        String name = nameField.getText().toString();

        // get quantity
        EditText quantityField = (EditText) findViewById(R.id.editText5);
        int quantity = Integer.valueOf(quantityField.getText().toString());


        for (ShoppingList shoppingList : LoadShoppingListActivity.shoppingLists) {
            if (shoppingList.getName().equals(shoppingListName)) {
                shoppingList.getProducts().add(new Product(name, quantity));
                break;
            }
        }

        Intent intent = new Intent(this, ShoppingListActivity.class);
        intent.putExtra( "shoppingList", shoppingListName );
        startActivity(intent);
    }
}
