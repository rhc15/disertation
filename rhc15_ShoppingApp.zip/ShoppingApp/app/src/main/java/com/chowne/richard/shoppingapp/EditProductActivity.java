package com.chowne.richard.shoppingapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import com.chowne.richard.shoppingapp.model.Product;
import com.chowne.richard.shoppingapp.model.ShoppingList;

/**
 * Created by Richard Chowne on 18/04/2017.
 */

/**
 * Android activity that EditProductActivity-to enable product manipulations.
 */
public class EditProductActivity extends AppCompatActivity {

    /**
     * string that holds the product to change name
     */
    private String productToChangeName;
    /**
     *holds the shoppinglist name
     */
    private String shoppingListName;

    /**
     * gets the edit product from the activity.
     * @param savedInstanceState see superclass.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_product);

        Intent intent = getIntent();

        productToChangeName = intent.getStringExtra("productName");
        int productQuantity = intent.getIntExtra("productQuantity", 0);
        shoppingListName = intent.getStringExtra("shoppingList");

        EditText nameField = (EditText) findViewById(R.id.editText2);
        nameField.setText(productToChangeName);
        EditText quantityField = (EditText) findViewById(R.id.editText3);
        quantityField.setText(String.valueOf(productQuantity));
    }

    /**
     * when the edited product name  and quantity is completed and the user,
     * clicks submit it will be changed and shown on the shopping list.after going through a check
     * and making sure it is being added to the current shopping list so that it can be viewed in the load shopping list section later.
     *
     * @param view the current activity.
     */
    // method for submit
    public void submit(View view) {
        EditText nameField = (EditText) findViewById(R.id.editText2);
        String name = nameField.getText().toString();

        // get quantity
        EditText quantityField = (EditText) findViewById(R.id.editText3);
        int quantity = Integer.valueOf(quantityField.getText().toString());

        ShoppingList currentShoppingList = null;
        for (ShoppingList shoppingList : LoadShoppingListActivity.shoppingLists) {
            if (shoppingListName.equals(shoppingList.getName())) {
                currentShoppingList = shoppingList;
                break;
            }
        }

        for (Product product : currentShoppingList.getProducts()) {
            if (product.getName().equals(productToChangeName)) {
                product.setName(name);
                product.setQuantity(quantity);
            }
        }

        Intent intent = new Intent(this, ShoppingListActivity.class);
        intent.putExtra("shoppingList", shoppingListName);
        startActivity(intent);
    }

}
