package com.chowne.richard.shoppingapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.chowne.richard.shoppingapp.model.Product;
import com.chowne.richard.shoppingapp.model.ShoppingList;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * Created by Richard Chowne on 13/03/2017.
 */

/**
 * Android Activity that holds the Main class, where the load shoppinglist and create shopping list and how to can be viewed .
 */
public class MainActivity extends AppCompatActivity {

    /**
     * initialise the android main activity and get teh shopping list from the load shopping list .
     *
     * @param savedInstanceState see superclass.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        LoadShoppingListActivity.shoppingLists = loadShoppingLists();
    }

    /**
     * button listner: when the how to button is pressed the how to activity will be displayed.
     *
     * @param view the current activity.
     */
    //called when user presses the how to button.
    public void guideButton(View view) {
        Intent intent = new Intent(this, HowToActivity.class);

        startActivity(intent);
    }


    /**
     * button listener: when the add products button is clicked it will load up the add shoppinglist activity class.
     *
     * @param view the current activity.
     */
    //loads up when the user presses the add manual button
    public void addShoppingList(View view) {
        Intent intent = new Intent(this, AddShoppingListActivity.class);
        startActivity(intent);

    }

    /**
     * button listener: the method that saves the load shopping list to be displayed as well as products that are added to the shoppinglist.
     *
     * @param view the current activity.
     */
    public void loadShoppingListActivity(View view) {
        Intent intent = new Intent(this, LoadShoppingListActivity.class);
        startActivity(intent);
    }

    /**
     * arraylist taht has shoppinglists int eh loadshoppinglist to be viewed and manipulated.
     * @return the shoppinglist to the loadlshoppinglist for modification.
     */
    private ArrayList<ShoppingList> loadShoppingLists() {
        ArrayList<ShoppingList> shoppingListsToReturn = new ArrayList<>();
        String listName = "MyList";

        try {
            openFileInput(listName);
        } catch (FileNotFoundException e) {
            try {
                openFileOutput(listName, Context.MODE_PRIVATE);
            } catch (FileNotFoundException e1) {
                e1.printStackTrace();
            }
        }


        FileInputStream inputStream;
        try {
            inputStream = openFileInput(listName);
            InputStreamReader isr = new InputStreamReader(inputStream);
            BufferedReader br = new BufferedReader(isr);
            String line;
            while ((line = br.readLine()) != null) {
                ShoppingList shoppingList = new ShoppingList(line);
                int productNo = Integer.valueOf(br.readLine());
                ArrayList<Product> products = new ArrayList<>();
                for (int i = 0; i < productNo; i++) {
                    String productLine = br.readLine();
                    String productQuantity = br.readLine();
                    products.add(new Product(productLine, Integer.valueOf(productQuantity)));
                }
                shoppingList.setProducts(products);
                shoppingListsToReturn.add(shoppingList);
            }
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return shoppingListsToReturn;
    }

}
