package com.chowne.richard.shoppingapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.chowne.richard.shoppingapp.model.Product;
import com.chowne.richard.shoppingapp.model.ShoppingList;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

import static com.chowne.richard.shoppingapp.LoadShoppingListActivity.shoppingLists;


/**
 * Created by Richard Chowne on 18/04/2017.
 */

/**
 * Android activity which holds the EditshoppingListACtivity
 */
public class EditShoppingListActivity extends AppCompatActivity {

    /**
     * holds the shoppinglist to change name.
     */
    private String shoppingListToChangeName;

    /**
     * the method will show let you enable the shopping list when the edit button
     * is clicked from the load shoppinglist button and when edit is clicked.
     *
     * @param savedInstanceState see superclass.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_shopping_list);

        Intent intent = getIntent();

        shoppingListToChangeName = intent.getStringExtra("shoppingList");
        EditText nameField = (EditText) findViewById(R.id.editText4);
        nameField.setText(shoppingListToChangeName);
    }

    /**
     * button listener :when edit is clicked it will check the shopping list to make sure that no products from the
     * shopping list do not get modified as well and goes through an input stream and the modified name
     * gets returned int he outputstream.
     *
     * @param view the current activity.
     */
    public void submit(View view) {
        EditText nameField = (EditText) findViewById(R.id.editText4);
        String name = nameField.getText().toString();

        for (ShoppingList shoppingList : shoppingLists) {
            if (shoppingList.getName().equals(shoppingListToChangeName)) {
                shoppingList.setName(name);
            }
        }

        // method for changing and loading a name upon hitting the edit button.
        String listName = "MyList";

        FileInputStream inputStream;
        try {
            inputStream = openFileInput(listName);
            InputStreamReader isr = new InputStreamReader(inputStream);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                if (line.equals(shoppingListToChangeName)) {
                    line = name;
                }
                sb.append(line);
                sb.append(System.getProperty("line.separator"));
            }
            inputStream.close();

            FileOutputStream outputStream;
            try {
                outputStream = openFileOutput(listName, Context.MODE_PRIVATE);
                outputStream.write(sb.toString().getBytes());
                //outputStream.write("".getBytes());
                outputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Intent intent = new Intent(this, LoadShoppingListActivity.class);
        startActivity(intent);
    }

}
