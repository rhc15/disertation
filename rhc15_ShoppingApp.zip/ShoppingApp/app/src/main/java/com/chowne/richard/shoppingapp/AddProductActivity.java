package com.chowne.richard.shoppingapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.chowne.richard.shoppingapp.scanner.ScannerActivity;

/**
 * Created by Richard Chowne on 21/04/2017.
 */

/**
 * Android activity that  Adds Products to the shopping list.
 */
public class AddProductActivity extends AppCompatActivity {

    /**
     *  holds the shoppinglist names to be displayed in load shopping list.
     */
    private String shoppingListName;

    /**
     * initialise android activity and gets the shopping list from the intent.
     *
     * @param savedInstanceState see superclass.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_product);
        shoppingListName = getIntent().getStringExtra("shoppingList");
    }

    /**
     * button listener: takes you to a new page where you can add products manually to the shopping list.
     *
     * @param view the current activity view.
     */
    public void button(View view) {
        Intent intent = new Intent(this, ManualAddProductActivity.class);
        intent.putExtra("shoppingList", shoppingListName);
        startActivity(intent);
    }

    /**
     * button listener: when the user clicks on scanner he will be taken to the scannerACtivity class where the camera will boot up requesting permission
     * to be enabled to access the camera on the device
     *
     * @param view the current android activity.
     */
    public void scanner(View view) {
        Intent intent = new Intent(this, ScannerActivity.class);
        intent.putExtra("shoppingList", shoppingListName);
        startActivity(intent);
    }
}
