package com.chowne.richard.shoppingapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import com.chowne.richard.shoppingapp.model.Product;
import com.chowne.richard.shoppingapp.model.ShoppingList;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

/**
 * Created by Richard  Chowne on 13/04/2017.
 */

/**
 * Android activity that holds the manual add product activity- so you can add products.
 */
public class ManualAddProductActivity extends AppCompatActivity {

    /**
     * holds the products in the shoppinglist.
     */
    private String intentShoppingList;

    /**
     * takes you to the add product manual page where you can add  the name of the product and quantity, to be added
     * to the shopping list.
     *
     * @param savedInstanceState see superclass.
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_product_manual);
        intentShoppingList = getIntent().getStringExtra("shoppingList");
    }

    /**
     * button listener :when submit is triggered after inputting the product name and quantity
     *
     * @param view the current activity.
     */
    public void submit(View view) {
        EditText nameField = (EditText) findViewById(R.id.editText2);
        String name = nameField.getText().toString();

        // get quantity
        EditText quantityField = (EditText) findViewById(R.id.editText3);
        int quantity = Integer.valueOf(quantityField.getText().toString());

        for (ShoppingList shoppingList : LoadShoppingListActivity.shoppingLists) {
            if (shoppingList.getName().equals(intentShoppingList)) {
                shoppingList.getProducts().add(new Product(name, quantity));
                break;
            }
        }

        Intent intent = new Intent(this, ShoppingListActivity.class);
        intent.putExtra("shoppingList", intentShoppingList);
        startActivity(intent);
    }
}

