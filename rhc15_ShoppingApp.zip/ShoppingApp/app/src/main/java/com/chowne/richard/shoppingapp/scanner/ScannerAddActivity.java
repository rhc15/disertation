package com.chowne.richard.shoppingapp.scanner;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import com.chowne.richard.shoppingapp.R;

/**
 * Created by Richard Chowne on 21/04/2017.
 */

/**
 *Android Activity that contains the scanner to add to shoppinglist.
 */
public class ScannerAddActivity extends AppCompatActivity {

    /**
     * string which contains the GTIN which retrieves the barcodes and sends requests to the api to retrieve the product name
     */
    private String gtin;
    /**
     * string that contains the Shopping list which scanned items get added to it.
     */
    private String shoppingListName;

    /**
     * this will add scanned products to the shopping lsit with the help of the GTIN (barcodes) and put them on the shoppinglist.
     *
     * @param savedInstanceState see superclass.
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scanner_add);

        Intent intent = getIntent();
        shoppingListName = intent.getStringExtra("shoppingList");
        gtin = intent.getStringExtra("gtin");

    }

    /**
     * Method for when submit it being executed it will put the product that has been scanned into the shopping list to be viewed
     * and manipulated through a request to the api through HttpsAddProduct.it will return the product through the gtin and user
     * can add quantity and view the name before submitting. This is all being done by a get and post request to the api to check,
     * if the product scanned is in the database, if it is not it will go through this all and make a post request so that when u
     * scan again you wont go through this step.
     *
     * @param view the current activity.
     */
    public void submit(View view) {
        EditText nameField = (EditText) findViewById(R.id.editText2);
        String name = nameField.getText().toString();

        new HttpsAddProduct(this, shoppingListName).execute(name, gtin);

        // post request
        Intent intent = new Intent(this, LoadingActivity.class);
        startActivity(intent);


    }
}
