package com.chowne.richard.shoppingapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import com.chowne.richard.shoppingapp.model.Product;

import com.chowne.richard.shoppingapp.model.ShoppingList;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

/**
 * Created by Richard Chowne on 18/04/2017.
 */

/**
 * Android activity that  AddsShoppingLists
 */
public class AddShoppingListActivity extends AppCompatActivity {
    /**
     * Method when create shopping list is pressed and then created which will be viewed in the load shopping list section.
     *
     * @param savedInstanceState see superclass.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_shopping_list);

    }

    /**
     *  button listener: This method adds the users shopping list to the load menu so that they can view it and modify it if need be
     * they have access to the shopping list and the products it holds and can modify it by adding more products or removing some.
     *
     * @param view  the current activity.
     */
    // adding the shopping list to the load menu.
    public void submit(View view) {
        EditText nameField = (EditText) findViewById(R.id.editText);
        String name = nameField.getText().toString();

        ShoppingList shoppingList = new ShoppingList(name);
        LoadShoppingListActivity.shoppingLists.add(shoppingList);
        String listName = "MyList";

        FileInputStream inputStream;
        try {
            inputStream = openFileInput(listName);
            InputStreamReader isr = new InputStreamReader(inputStream);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
                sb.append(System.getProperty("line.separator"));
            }
            sb.append(shoppingList.getName());
            sb.append(System.getProperty("line.separator"));
            sb.append(shoppingList.getProducts().size());
            sb.append(System.getProperty("line.separator"));
            inputStream.close();

            FileOutputStream outputStream;
            try {
                outputStream = openFileOutput(listName, Context.MODE_PRIVATE);
                outputStream.write(sb.toString().getBytes());
                //outputStream.write("".getBytes());
                outputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Intent intent = new Intent(this, LoadShoppingListActivity.class);
        startActivity(intent);
    }
}
