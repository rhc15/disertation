

Name: Shopping Application , Version: 1.0 , IDE: Android Studio vr(2.3.1)

System Requirments :
you need to have the latest Android Studio(2.3.1) which can be download at the Android Developers website. You also need to install the virtual machine which is of an APi of 24 and have to be of android target 7.0 which will be 1GB in size. 
 You will need about 4 GB to install Android studio and another 2GB to download the drivers and the Virtual machine.

Installation:
this does not require you to install anything, the only thign is that you should have the latest version of Android Studio to be able to run The Shoping Application.

Main Files Location:(to run on other IDEs like eclipse or netbeans)
To access the applications files if you go to the Folder(ShoppingApp) all the files you can access to are in the app sub folder and there you can see the folders which lead to the clas files. Everything is in the "src" file the test classes and the resources the layouts everything is there. 

Description:(how to use aswell) 
This is a shopping helper application where the user (you) can create a shopping list to add products into it.
You can edit and delete the shopping List as well as View it. When you view a shopping List you will see an empty box and a button below.
"ADD products" in there you can start to add products to your shopping list either by manually adding it as writing the name and quantity
of the product or you can scan the product. 

If you decide to scan it you will be presented with a few steps as well as a message, if the product
you scan is not in the database then you will be asked to add it or no if you click "Yes" then it adds it to the database as well as lets you add 
the name and amount you want to be displayed in the shopping list. If you click "NO" then you will be taken to the scanner again to scan a new product.

Credit:
Rhc15- programmer

Acknowledgments:
i would like to give my acknowlegment to my professor who was supervising me in the duration of this project as well as thanks to my friends for giving me feedback as well as useful input to better myself as well as make me have a passion for what i do .

Contact:
if there are any issues you can contact me by emailing me at:- rhc15@aber.ac.uk 
for any issues or feedback or if you have any ideas on ways 
i can improve the application.(shopping helper)

